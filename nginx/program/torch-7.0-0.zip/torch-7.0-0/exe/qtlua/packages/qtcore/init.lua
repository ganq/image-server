
require 'qt'
qt.require 'libqtcore'

local qt = qt

