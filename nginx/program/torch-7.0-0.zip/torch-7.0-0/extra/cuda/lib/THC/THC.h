#ifndef THC_INC
#define THC_INC

#include "THCGeneral.h"
#include "THCStorage.h"
#include "THCTensor.h"
#include "THCTensorRandom.h"
#include "THCTensorMath.h"
#include "THCTensorConv.h"

#endif
