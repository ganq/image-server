xlua
====

Has moved to a more community friendly [repo](https://github.com/torch/xlua).
