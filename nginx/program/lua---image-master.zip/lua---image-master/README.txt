DEPENDENCIES:
Torch7 (www.torch.ch)

INSTALL:
$ torch-pkg install image

USE:
$ torch
> require 'image'
> l = image.lena()
> image.display(l)
