
-- Package library:
local gm = {
   Image = require 'graphicsmagick.Image',
   convert = require 'graphicsmagick.convert'
}

-- Export:
return gm

